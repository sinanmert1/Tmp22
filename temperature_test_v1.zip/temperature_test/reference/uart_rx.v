// ----------------------------------------------------------------------------
// FILE NAME      : uart_rx.v
// COMPANY        : TEI
// AUTHOR         : Seyma Guler
// AUTHOR'S EMAIL : seyma.guler@tei.com.tr
// -----------------------------------------------------------------------------
// RELEASE HISTORY
// VERSION:      DATE:        AUTHOR:      DESCRIPTION:
// 0.0        01.12.2023    Seyma Guler    file created.
// 0.1        07.31.2024    Seyma Guler    start bit START_BIT_TIMER_LIM kadar LOW surulurse RX baslatilacaktir kosulu eklenmsitir.
// -----------------------------------------------------------------------------
// MODULE DESCRIPTION : This file contains the UART Receiver. This receiver is able
// to receive DATA_WIDTH bits of serial data, configurable baudrate from parameter.
// To initiate data receiving start condition must be provided. (rx is driven low)
// When receiving operation is complete rx_done_o will be driven high for one clock cycle.
// Data read from UART is stored in rx_dout_o until a new data read.
// 1- Uart protocol LSB first
// 2- Stop_bit is set by STOP_BIT parameter.
// -----------------------------------------------------------------------------
// REUSE ISSUES
// Reset Strategy      : Asynchronous, active low system level reset
// Clock Domains       : clk_i
// Asynchronous I/F    : rst_al_i
// Instantiations      : N/A
// Synthesizable (y/n) : Y
// Other               :
// ----------------------------------------------------------------------------

//`timescale <time_units> / <precision>

module uart_rx
#( parameter CLK_FREQ        = 100_000_000,  //system clk freq
   parameter BAUDRATE        = 921600,       //uart baudrate
   parameter DATA_WIDTH      = 8,            //data width
   parameter STOP_BIT        = 1             //Stop_bit_timer = data bit timer*STOP_BIT_TIMER_COEF
 )(
     input                   clk_i,          //system clk
     input                   rst_al_i,       //active-low asynchronous reset
     input                   rx_i,           //uart rx

     output                  rx_busy_o,
     output                  rx_done_o,      //uart valid data received
     output [DATA_WIDTH-1:0] rx_dout_o       //uart received data
 );


//###############################################################################
//                                      CONSTANTS
//###############################################################################
localparam BIT_TIMER_LIM       = CLK_FREQ/BAUDRATE;    // timer limit to receive 1 bit due to CLK_FREQ and BAUDRATE
localparam START_BIT_TIMER_LIM = (BIT_TIMER_LIM/2);    // to sample data in the middle of the bit duration
localparam STOP_BIT_TIMER_LIM  = BIT_TIMER_LIM*STOP_BIT;

//###############################################################################
//                                      COUNTERS
//###############################################################################
reg [$clog2(BIT_TIMER_LIM):0]       bit_timer_cntr_r;
reg [$clog2(START_BIT_TIMER_LIM):0] start_bit_timer_cntr_r;
reg [$clog2(STOP_BIT_TIMER_LIM):0]  stop_bit_timer_cntr_r;
reg [$clog2(DATA_WIDTH):0]          bit_cntr_r;

//###############################################################################
//                                    SIGNALS
//###############################################################################
//output registers
reg                  rx_done_r;
reg [DATA_WIDTH-1:0] rx_dout_r;
reg                  rx_busy_r;
//d-ff
reg                  rx_d1_r;
reg                  rx_d2_r;
reg                  rx_done_ff_r;
reg [DATA_WIDTH-1:0] rx_dout_ff_r;
reg                  rx_busy_ff_r;
//enable signals
reg                  enable_start_bit_timer_r;
reg                  enable_stop_bit_timer_r;
reg                  enable_bit_timer_r;
reg                  data_rx_done_r;
//###############################################################################
//                               STATE MACHINE
//###############################################################################
localparam STATE_WIDTH = 4;
localparam [STATE_WIDTH-1:0]
           S_IDLE       = 'd1,    // wait for start bit
           S_START      = 'd2,    // receive start bit
           S_DATA_RX    = 'd4,    // data rx
           S_STOP       = 'd8;    // receive stop bit
reg [STATE_WIDTH-1:0] state, next_state /* synthesis syn_encoding = "safe,onehot" */;

//###############################################################################
//                              STATE MACHINE PROCESS
//###############################################################################
always@(posedge clk_i or negedge rst_al_i) begin
    if(rst_al_i == 1'b0) begin
        state <= S_IDLE;
    end
    else begin
        state <= next_state;
    end
end

//###############################################################################
//                              MAIN PROCESS
//###############################################################################
always@(*) begin
    // begin default assignment
    next_state               = 'dx;
    enable_start_bit_timer_r = 1'b0;
    enable_bit_timer_r       = 1'b0;
    enable_stop_bit_timer_r  = 1'b0;
    rx_done_r                = 1'b0;
    rx_busy_r                = 1'b0;
    // end default
    case(state)
        S_IDLE: begin
            next_state  = S_IDLE;
            if(rx_d2_r==1'b0) begin
                next_state               = S_START;
                enable_start_bit_timer_r = 1'b1;
                rx_busy_r                = 1'b1;
            end
            else begin
                next_state  = S_IDLE;
            end
        end //end_S_IDLE

        S_START: begin
            next_state                   = S_START;
            if(rx_d2_r==1'b0) begin
                enable_start_bit_timer_r     = 1'b1;
                if(start_bit_timer_cntr_r == START_BIT_TIMER_LIM -1) begin
                    enable_start_bit_timer_r = 1'b0;
                    enable_bit_timer_r       = 1'b1;
                    rx_busy_r                = 1'b1;
                    next_state               = S_DATA_RX;
                end
            end
            else begin
                next_state  = S_IDLE;
            end
        end //end_S_START

        S_DATA_RX: begin
            next_state           = S_DATA_RX;
            enable_bit_timer_r   = 1'b1;
            rx_busy_r            = 1'b1;
            if(data_rx_done_r == 1'b1) begin
                next_state              = S_STOP;
                enable_bit_timer_r      = 1'b0;
                enable_stop_bit_timer_r = 1'b1;
            end
        end //end_S_DATA_RX

        S_STOP: begin
            next_state              = S_STOP;
            enable_stop_bit_timer_r = 1'b1;
            rx_busy_r               = 1'b1;
            if(stop_bit_timer_cntr_r == STOP_BIT_TIMER_LIM) begin
                rx_done_r               = 1'b1;
                enable_stop_bit_timer_r = 1'b0;
                next_state              = S_IDLE;
            end
        end // end_S_STOP

        default :
            next_state  = S_IDLE;
    endcase
end

//###############################################################################
//                                  D-FF PROCESS
//###############################################################################
always@(posedge clk_i or negedge rst_al_i) begin
    if(rst_al_i == 1'b0) begin
        rx_d1_r <= 1'b1;
        rx_d2_r <= 1'b1;
    end
    else begin
        rx_d1_r <= rx_i;
        rx_d2_r <= rx_d1_r;
    end
end

//###############################################################################
//                                  COUNTER PROCESS
//###############################################################################
always@(posedge clk_i or negedge rst_al_i) begin
    if(rst_al_i == 1'b0) begin
        start_bit_timer_cntr_r <= 0;
        stop_bit_timer_cntr_r  <= 0;
        bit_timer_cntr_r       <= 0;
        bit_cntr_r             <= 0;
        rx_dout_r              <= 0;
        data_rx_done_r         <= 0;
        rx_done_ff_r           <= 0;
        rx_dout_ff_r           <= 0;
        rx_busy_ff_r           <= 0;
    end
    else begin
        rx_done_ff_r           <= rx_done_r;
        rx_dout_ff_r           <= rx_dout_r;
        rx_busy_ff_r           <= rx_busy_r;

        if(enable_start_bit_timer_r==1'b1) begin
            if(start_bit_timer_cntr_r == START_BIT_TIMER_LIM -1) begin
                start_bit_timer_cntr_r <= 0;
            end
            else begin
                start_bit_timer_cntr_r <= start_bit_timer_cntr_r+1;
            end
        end
        else begin
            start_bit_timer_cntr_r <= 0;
        end

        if(enable_bit_timer_r==1'b1) begin
            if(bit_timer_cntr_r == BIT_TIMER_LIM -1) begin
                bit_timer_cntr_r      <= 0;
                rx_dout_r[bit_cntr_r] <= rx_d2_r;
                if(bit_cntr_r == DATA_WIDTH-1) begin
                    bit_cntr_r     <= 0;
                    data_rx_done_r <= 1'b1;
                end
                else
                    bit_cntr_r    <= bit_cntr_r+1;
            end
            else begin
                bit_timer_cntr_r  <= bit_timer_cntr_r+1;
            end
        end
        else begin
            bit_timer_cntr_r       <= 0;
            bit_cntr_r             <= 0;
            data_rx_done_r         <= 1'b0;
        end

        if(enable_stop_bit_timer_r==1'b1) begin
            if(stop_bit_timer_cntr_r == STOP_BIT_TIMER_LIM) begin
                stop_bit_timer_cntr_r <= 0;
            end
            else begin
                stop_bit_timer_cntr_r <= stop_bit_timer_cntr_r+1;
            end
        end
        else begin
            stop_bit_timer_cntr_r <= 0;
        end
    end // end rising_edge
end // end always


//###############################################################################
//                              PORT ASSIGNMENT
//###############################################################################
assign rx_busy_o = rx_busy_ff_r;
assign rx_done_o = rx_done_ff_r;
assign rx_dout_o = rx_dout_ff_r;

endmodule

