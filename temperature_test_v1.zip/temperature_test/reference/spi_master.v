// -----------------------------------------------------------------------------
// FILE NAME      : spi_master.v
// COMPANY        : TEI
// AUTHOR         : Seyma Guler
// AUTHOR'S EMAIL : seyma.guler@tei.com.tr
// -----------------------------------------------------------------------------
// RELEASE HISTORY
// VERSION:      DATE:        AUTHOR:      DESCRIPTION:
// 1.0        2024.05.06    Seyma Guler    file created.
// -----------------------------------------------------------------------------
// MODULE DESCRIPTION :
// Bu modul SPI haberlesme arayuzu icin olusturulmustur.
// SPI modu, data genisligi ve timing spesifikasyonlari parametreler araciligiyla kalibre edilebilir.
// MOSI IDLE durumda HIGH surulmektedir.
// Data shift LSB first olarak tasarlanmistir.
// 1- Hold time CS_HOLD_TIME_CC parametresi ile belirlenir.
// 2- Setup time CS_SETUP_TIME_CC parametresi ile belirlenir.
// 3- CS_SETUP_TIME_CC ve CS_HOLD_TIME_CC en az SCLK_ACTIVE_TIME_CC kadar olabilir.
// 4- CS_SETUP_TIME_CC ve CS_HOLD_TIME_CC, SCLK_ACTIVE_TIME_CC'dan az ise tasarim icerisinde SCLK_ACTIVE_TIME_CC'a esitlenir.
// 5- SPI hatti enable edildiginde (spi_enable_i=HIGH), haberlesme tamamlanana kadar busy_o HIGH surulur.
// 6- busy_o=LOW ise yeni spi transferi baslatilabilir.
// 7- SPI_WIDTH genisligine sahip datanin spi hattinda tx/rx islemi tamamlandiginda data_valid_o 1 PULSE HIGH surulur.
// 8- Burst mode kullanilmak isteniyorsa data_valid_o HIGH suruldukten sonra spi_enable_i=HIGH surulmelidir.
// 9- Burst mode kullanilmak istenmiyorsa data_valid_o HIGH suruldukten sonra spi_enable_i=LOW surulmelidir.
//
// -----------------------------------------------------------------------------
// REUSE ISSUES
// Reset Strategy      : Asynchronous, active low system level reset
// Clock Domains       : clk_i
// Asynchronous I/F    : rst_al_i
// Instantiations      : N/A
// Synthesizable (y/n) : Y
// Other               :
// ----------------------------------------------------------------------------

//`timescale <time_units> / <precision>

module spi_master
    #(
         parameter       SCLK_ACTIVE_TIME_CC      = 20, //! SCLK active time clock counter (SCLK_ACTIVE_TIME_CC valid min value: 3)
         parameter       CS_SETUP_TIME_CC         = 1,  //! Output delay SPI_CS valid before first clock edge
         parameter       CS_HOLD_TIME_CC          = 1,  //! Output delay SPI_CS valid after last clock edge
         parameter       CS_INACTIVE_TIME_CC      = 40, //! CS high time
         parameter [1:0] SPI_MODE                 = 0,  //! SPI mode
         parameter       SPI_WIDTH                = 8   //! Number of bits to serialize
     )
     (
         input                  clk_i,          //!system clk
         input                  rst_al_i,       //!active-low asynchronous reset
         input                  spi_enable_i,   //!initiate transaction
         input                  miso_i,         //!master in, slave out
         input  [SPI_WIDTH-1:0] tx_data_i,      //!data to transmit

         output [SPI_WIDTH-1:0] rx_data_o,     //!received data from slave
         output                 cs_o,          //!chip select
         output                 sclk_o,        //!spi clk
         output                 mosi_o,        //!master out, slave in
         output                 data_valid_o,  //!1 Pulse - read or/and write operation finished according to SPI_WIDTH
         output                 busy_o         //!indicates transaction in progress
     );


    //###############################################################################
    //                                      CONSTANTS
    //###############################################################################
    localparam CPOL = SPI_MODE[1];
    localparam CPHA = SPI_MODE[0];
    localparam [$clog2(CS_SETUP_TIME_CC):0] SETUP_TIME_CC = (CS_SETUP_TIME_CC > SCLK_ACTIVE_TIME_CC) ? CS_SETUP_TIME_CC-SCLK_ACTIVE_TIME_CC+1 : 0;
    localparam [$clog2(CS_HOLD_TIME_CC):0]  HOLD_TIME_CC  = (CPHA == 1'b0) ?  ((CS_HOLD_TIME_CC > SCLK_ACTIVE_TIME_CC) ? CS_HOLD_TIME_CC-1 : SCLK_ACTIVE_TIME_CC-1):
               ((CS_HOLD_TIME_CC > SCLK_ACTIVE_TIME_CC) ? CS_HOLD_TIME_CC-SCLK_ACTIVE_TIME_CC-1 : 0);
    //###############################################################################
    //                                      COUNTERS
    //###############################################################################
    reg [$clog2(SCLK_ACTIVE_TIME_CC):0] edge_cntr_r/*synthesis syn_keep=1*/;
    reg [$clog2(SETUP_TIME_CC):0]       setup_cntr_r/*synthesis syn_keep=1*/;
    reg [$clog2(HOLD_TIME_CC):0]        hold_cntr_r/*synthesis syn_keep=1*/;
    reg [$clog2(CS_INACTIVE_TIME_CC):0] cs_cntr_r/*synthesis syn_keep=1*/;
    reg [$clog2(SPI_WIDTH):0]           trans_cntr_r/*synthesis syn_keep=1*/;
    reg [$clog2(SPI_WIDTH):0]           rx_cntr_r/*synthesis syn_keep=1*/;
    reg [$clog2(SPI_WIDTH):0]           tx_cntr_r/*synthesis syn_keep=1*/;
    reg [$clog2(SPI_WIDTH):0]           trans_cntr_ff_r/*synthesis syn_keep=1*/;
    reg [$clog2(SPI_WIDTH):0]           rx_cntr_ff_r/*synthesis syn_keep=1*/;
    reg [$clog2(SPI_WIDTH):0]           tx_cntr_ff_r/*synthesis syn_keep=1*/;

    //###############################################################################
    //                                    SIGNALS
    //###############################################################################
    //output registers
    reg cs_r;
    reg sclk_q;
    reg sclk_r;
    reg mosi_r;
    reg mosi_ff_r;
    reg data_valid_r;
    reg busy_r;
    reg [SPI_WIDTH -1 :0] tx_data_ff_r/*synthesis syn_keep=1*/;
    reg [SPI_WIDTH -1 :0] rx_data_ff_r/*synthesis syn_keep=1*/;
    reg [SPI_WIDTH -1 :0] tx_data_r/*synthesis syn_keep=1*/;
    reg [SPI_WIDTH -1 :0] rx_data_r/*synthesis syn_keep=1*/;
    //internal signals
    reg sclk_enable_r;
    reg sclk_fall_r;
    reg sclk_rise_r;
    reg sclk_prev_r;
    reg cs_inactive_en_r;
    reg hold_cntr_en_r;
    reg sclk_q2;
    //wires
    wire capture_en_w;
    wire shift_en_w;

    //###############################################################################
    //                               STATE MACHINE
    //###############################################################################
    localparam STATE_WIDTH = 6;
    localparam [STATE_WIDTH-1:0]
               S_IDLE        = 'd1,    //!wait for spi enable
               S_TRANSFER    = 'd2,    //!SPI transfer state
               S_DVLD        = 'd8,    //!data valid signal, wait for burst usage
               S_HOLD_TIME   = 'd16,   //!hold time
               S_CS_INACTIVE = 'd32;   //!CS high time
    reg [STATE_WIDTH-1:0] state, next_state /* synthesis syn_encoding = "safe,onehot" */;

    //###############################################################################
    //                              STATE MACHINE PROCESS
    //###############################################################################
    always@(posedge clk_i or negedge rst_al_i) begin
        if(!rst_al_i) begin
            state <= S_IDLE;
        end
        else begin
            state <= next_state;
        end
    end

    //###############################################################################
    //                               RISE/FALL DETECT PROCESS
    //###############################################################################
    //RISEFALL_DETECT procedure assigns sclk_rise and sclk_fall signals in a combinational logic.
    always@(*) begin
        if(!rst_al_i) begin
            sclk_fall_r = 0;
            sclk_rise_r = 0;
        end
        else begin
            if(sclk_r==1'b1 && sclk_prev_r==1'b0)
                sclk_rise_r = 1'b1;
            else
                sclk_rise_r = 1'b0;

            if(sclk_r==1'b0 && sclk_prev_r==1'b1)
                sclk_fall_r = 1'b1;
            else
                sclk_fall_r = 1'b0;
        end
    end

    //###############################################################################
    //                              MAIN PROCESS
    //###############################################################################
    always@(*) begin
        //default assignment
        //next_state       = 'dx; //Testbench icin eklenmistir state gecisini kontrol eder, tasarimda kullanmayiniz.
        busy_r           = 1'b0;
        cs_r             = 1'b1;
        mosi_r           = 1'b1;
        cs_inactive_en_r = 1'b0;
        data_valid_r     = 1'b0;
        sclk_q           = CPOL;
        sclk_enable_r    = 1'b0;
        hold_cntr_en_r   = 1'b0;
        tx_data_r        = tx_data_ff_r;
        trans_cntr_r     = trans_cntr_ff_r;
        rx_cntr_r        = rx_cntr_ff_r;
        tx_cntr_r        = tx_cntr_ff_r;
        rx_data_r        = rx_data_ff_r;
        //end default
        case(state)
            S_IDLE: begin
                cs_r          = 1'b1;
                mosi_r        = 1'b1;
                sclk_enable_r = 1'b0;
                busy_r        = 1'b0;
                trans_cntr_r  = 0;
                rx_cntr_r     = SPI_WIDTH-1;
                tx_cntr_r     = SPI_WIDTH-1;
                if(spi_enable_i == 1'b1) begin
                    tx_data_r     = tx_data_i;
                    sclk_enable_r = 1'b1;
                    next_state    = S_TRANSFER;
                    rx_data_r     = 0;
                end
                else begin
                    next_state    = S_IDLE;
                end
            end //end S_IDLE

            S_TRANSFER: begin
                next_state     = S_TRANSFER;
                busy_r         = 1'b1;
                sclk_enable_r  = 1'b1;
                cs_r           = 1'b0;
                mosi_r         = tx_data_r[tx_cntr_ff_r];
                sclk_q         = sclk_r;
                if(trans_cntr_ff_r == SPI_WIDTH) begin
                    next_state     = S_DVLD;
                    data_valid_r   = 1'b1;
                end
                else begin
                    if(capture_en_w == 1'b1) begin
                        trans_cntr_r             = trans_cntr_ff_r+1;
                        rx_data_r[rx_cntr_ff_r]  = miso_i;
                        if(rx_cntr_ff_r>0) begin
                            rx_cntr_r = rx_cntr_ff_r -1;
                        end
                    end
                    if(shift_en_w == 1'b1 && tx_cntr_ff_r>0 && trans_cntr_ff_r>0) begin
                        tx_cntr_r    = tx_cntr_ff_r-1;
                        mosi_r       = tx_data_r[tx_cntr_ff_r-1];
                    end
                end
            end //end S_TRANS

            S_DVLD: begin
                busy_r        = 1'b1;
                sclk_enable_r = 1'b1;
                next_state    = S_DVLD;
                cs_r          = 1'b0;
                mosi_r        = tx_data_r[0];
                data_valid_r  = 1'b0;
                trans_cntr_r  = 0;
                rx_cntr_r     = SPI_WIDTH-1;
                tx_cntr_r     = SPI_WIDTH-1;
                case(CPHA)
                    1'b0: begin
                        sclk_q = sclk_r;
                    end
                    1'b1: begin
                        sclk_q = CPOL;
                    end
                endcase
                if(shift_en_w == 1'b1) begin
                    if(spi_enable_i == 1'b1) begin
                        tx_data_r    = tx_data_i;
                        mosi_r       = tx_data_i[SPI_WIDTH-1];
                        sclk_q       = sclk_r;
                        next_state   = S_TRANSFER;
                        cs_r         = 1'b0;
                        rx_data_r    = 0;
                    end
                    else begin
                        tx_data_r      = 0;
                        sclk_q         = CPOL;
                        next_state     = S_HOLD_TIME;
                        sclk_enable_r  = 1'b0;
                        mosi_r         = 1'b1;
                    end
                end
            end //end S_DVLD

            S_HOLD_TIME : begin
                busy_r         = 1'b1;
                next_state     = S_HOLD_TIME;
                trans_cntr_r   = 0;
                rx_cntr_r      = SPI_WIDTH-1;
                tx_cntr_r      = SPI_WIDTH-1;
                hold_cntr_en_r = 1'b1;
                sclk_q         = CPOL;
                cs_r           = 1'b0;
                if(hold_cntr_r == HOLD_TIME_CC) begin
                    next_state     = S_CS_INACTIVE;
                    cs_r           = 1'b1;
                    sclk_enable_r  = 1'b0;
                    mosi_r         = 1'b1;
                    hold_cntr_en_r = 1'b0;
                end
            end //end S_HOLD_TIME

            S_CS_INACTIVE: begin
                busy_r           = 1'b1;
                next_state       = S_CS_INACTIVE;
                trans_cntr_r     = 0;
                rx_cntr_r        = SPI_WIDTH-1;
                tx_cntr_r        = SPI_WIDTH-1;
                cs_inactive_en_r = 1'b1;
                cs_r             = 1'b1;
                sclk_enable_r    = 1'b0;
                if(cs_cntr_r == CS_INACTIVE_TIME_CC-1) begin
                    next_state  = S_IDLE;
                end
            end //end S_CS_INACTIVE

            default :
                next_state      = S_IDLE;
        endcase
    end

    //###############################################################################
    //                              SCLK_GEN PROCESS
    //###############################################################################
    //In the SCLK_GEN procedure, internal sclk signal is generated if sclk_en signal is logic high.
    always@(posedge clk_i or negedge rst_al_i) begin
        if(!rst_al_i) begin
            edge_cntr_r  <= 0;
            sclk_r       <= CPOL;
            sclk_prev_r  <= CPOL;
            sclk_q2      <= CPOL;
            setup_cntr_r <= 0;
        end
        else begin
            sclk_prev_r  <= sclk_r;
            sclk_q2      <= sclk_q;
            if(sclk_enable_r == 1'b1) begin
                if(setup_cntr_r == SETUP_TIME_CC) begin
                    if(edge_cntr_r == SCLK_ACTIVE_TIME_CC-1) begin
                        sclk_r      <= ~sclk_r;
                        edge_cntr_r <= 0;
                    end
                    else begin
                        edge_cntr_r <= edge_cntr_r +1;
                    end
                end
                else begin
                    setup_cntr_r <= setup_cntr_r +1;
                end
            end
            else begin
                edge_cntr_r    <= 0;
                sclk_r         <= CPOL;
                setup_cntr_r   <= 0;
            end
        end
    end

    //###############################################################################
    //                            CS HIGH TIME PROCESS
    //###############################################################################
    always@(posedge clk_i or negedge rst_al_i) begin
        if(!rst_al_i) begin
            cs_cntr_r        <= 0;
        end
        else begin
            if(cs_inactive_en_r==1'b1) begin
                if(cs_cntr_r == CS_INACTIVE_TIME_CC-1) begin
                    cs_cntr_r <= 0;
                end
                else begin
                    cs_cntr_r <= cs_cntr_r +1;
                end
            end
            else begin
                cs_cntr_r    <= 0;
            end
        end
    end

    //###############################################################################
    //                           HOLD TIME PROCESS
    //###############################################################################
    always@(posedge clk_i or negedge rst_al_i) begin
        if(!rst_al_i) begin
            hold_cntr_r      <= 0;
        end
        else begin
            if(hold_cntr_en_r==1'b1) begin
                if(hold_cntr_r == HOLD_TIME_CC) begin
                    hold_cntr_r <= 0;
                end
                else begin
                    hold_cntr_r <= hold_cntr_r +1;
                end
            end
            else
                hold_cntr_r <= 0;
        end
    end

    //###############################################################################
    //                                 FF PROCESS
    //###############################################################################
    always@(posedge clk_i or negedge rst_al_i) begin
        if(!rst_al_i) begin
            tx_data_ff_r    <= 0;
            rx_data_ff_r    <= 0;
            trans_cntr_ff_r <= 0;
            rx_cntr_ff_r    <= SPI_WIDTH-1;
            tx_cntr_ff_r    <= SPI_WIDTH-1;
            mosi_ff_r       <= 0;
        end
        else begin
            rx_data_ff_r    <= rx_data_r;
            tx_data_ff_r    <= tx_data_r;
            trans_cntr_ff_r <= trans_cntr_r;
            rx_cntr_ff_r    <= rx_cntr_r;
            tx_cntr_ff_r    <= tx_cntr_r;
            mosi_ff_r       <= mosi_r;
        end
    end

    //###############################################################################
    //                              WIRE ASSIGNMENT
    //###############################################################################
    assign capture_en_w      = (SPI_MODE == 2'b00 || SPI_MODE == 2'b11) ? sclk_rise_r : sclk_fall_r;      // miso_en -> data capture en
    assign shift_en_w        = (SPI_MODE == 2'b00 || SPI_MODE == 2'b11) ? sclk_fall_r : sclk_rise_r;      // mosi_en -> data shift en
    assign rx_data_o         =  rx_data_ff_r;
    assign cs_o              =  cs_r;
    assign sclk_o            =  sclk_q2;
    assign mosi_o            =  mosi_ff_r;
    assign data_valid_o      =  data_valid_r;
    assign busy_o            =  busy_r;

endmodule

