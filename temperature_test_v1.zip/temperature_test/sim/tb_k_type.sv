`timescale 1ns/1ps
module tb_k_type;
    reg clk=0;
    always #10 clk=~clk;
    reg rst=0;
    reg [1:0] start=0;
    reg signed [23:0] code;
    reg signed [31:0] cj;
    wire [1:0] busy,done,err;
    wire signed [31:0] result [0:1];
    temp_test_k_type #(.ADC_VREF_UV(2048000)) d0
        (clk,rst,start[0],code,cj,busy[0],done[0],err[0],result[0]);
    temp_test_k_type #(.ADC_VREF_UV(2500000)) d1
        (clk,rst,start[1],code,cj,busy[1],done[1],err[1],result[1]);
    integer fd,n,sel,adc,cjq,expected,error_expected,count=0,delta,max_delta=0;
    initial begin
        repeat(5) @(negedge clk);
        rst=1;
        fd=$fopen("conversion_vectors.txt","r");
        if(!fd) $fatal(1,"Cannot open conversion_vectors.txt");
        while(!$feof(fd)) begin
            n=$fscanf(fd,"%d %d %d %d %d\n",sel,adc,cjq,expected,error_expected);
            if(n!=5) $fatal(1,"Invalid vector");
            @(negedge clk); code=adc; cj=cjq; start=1<<sel;
            @(negedge clk); start=0;
            wait(done[sel]);
            if(err[sel]!==error_expected[0])
                $fatal(1,"Error mismatch vector %0d: adc=%0d cj=%0d err=%0b expected=%0d",count,adc,cjq,err[sel],error_expected);
            if(!error_expected) begin
                delta=result[sel]-expected;
                if(delta<0) delta=-delta;
                if(delta>max_delta) max_delta=delta;
                if(delta>15) $fatal(1,"Temperature mismatch vector %0d: got %0d expected %0d",count,result[sel],expected);
            end
            @(negedge clk);
            count=count+1;
        end
        $fclose(fd);
        $display("PASS: %0d conversion vectors, both VREF settings, maximum error %0d centi-C",count,max_delta);
        $finish;
    end
    initial begin #10000000; $fatal(1,"Conversion test timeout"); end
endmodule
