`timescale 1ns/1ps
// SIMULATION ONLY. These are stimulus sources, NOT sensor controllers.
// Never add this file to the FPGA/synthesis source set.
// Port/parameter names follow the supplied screenshots. No SPI/I2C model here.
module ads1220_thrmcpl_controller #(
    parameter SYS_CLOCK_FREQ=50_000_000,
    parameter [3:0] CONF0_MUX=3,
    parameter [2:0] CONF0_GAIN=5,
    parameter [1:0] CONF2_VREF=0
)(
    input clk_i, rst_al_i, drdy_al_i, miso_i,
    output cs_o, sclk_o, mosi_o,
    output reg signed [23:0] tc_data_o=0,
    output reg signed [15:0] cj_data_o=0,
    output reg data_valid_o=0, cfg_error_o=0, drdy_timeout_error_o=0
);
    assign cs_o=1;
    assign sclk_o=0;
    assign mosi_o=0;
endmodule

module tmp117_controller #(
    parameter SYS_CLK_FREQ=50_000_000,
    parameter I2C_BUS_CLK_FREQ=100_000,
    parameter NUM_SENSORS=1,
    parameter [6:0] DEVICE_ADDR_0=7'h48
)(
    input clk_i, rst_al_i,
    inout tmp117_scl_io, tmp117_sda_io,
    output reg tmp117_s0_data_valid_o=0,
    output reg [15:0] tmp117_s0_data_raw_o=0,
    output reg tmp117_s0_id_error_o=0, tmp117_s0_cfg_error_o=0, tmp117_s0_range_error_o=0,
    output tmp117_s1_data_valid_o,
    output [15:0] tmp117_s1_data_raw_o,
    output tmp117_s1_id_error_o, tmp117_s1_cfg_error_o, tmp117_s1_range_error_o
);
    assign tmp117_scl_io=1'bz;
    assign tmp117_sda_io=1'bz;
    assign tmp117_s1_data_valid_o=0;
    assign tmp117_s1_data_raw_o=0;
    assign tmp117_s1_id_error_o=0;
    assign tmp117_s1_cfg_error_o=0;
    assign tmp117_s1_range_error_o=0;
endmodule
