`timescale 1ns/1ps
// Full wrapper -> conversion -> formatter -> physical UART TX pin.
// Existing sensor controllers are replaced ONLY IN THIS TEST by port models.
module uart_scenario #(parameter EXTERNAL_CJ=1)(output reg finished=0);
    reg clk=0, rst=0;
    always #10 clk=~clk; // Actual intended 50 MHz clock.
    wire tx;
    tri1 scl1,sda1,scl2,sda2;
    temperature_test_top #(
        .REPORT_PERIOD_MS(20), .STALE_TIMEOUT_MS(60), .USE_EXTERNAL_CJ(EXTERNAL_CJ)
    ) dut (
        .clk_i(clk), .rst_al_i(rst),
        .ads1_miso_i(1'b0), .ads1_drdy_al_i(1'b1),
        .ads1_cs_o(), .ads1_sclk_o(), .ads1_mosi_o(),
        .ads2_miso_i(1'b0), .ads2_drdy_al_i(1'b1),
        .ads2_cs_o(), .ads2_sclk_o(), .ads2_mosi_o(),
        .tmp1_scl_io(scl1), .tmp1_sda_io(sda1),
        .tmp2_scl_io(scl2), .tmp2_sda_io(sda2), .uart_tx_o(tx)
    );
    task publish(input integer a,b,c,d,e,f);
        begin
            @(negedge clk);
            dut.u_ads1.tc_data_o=a; dut.u_ads2.tc_data_o=b;
            dut.u_ads1.cj_data_o=c; dut.u_ads2.cj_data_o=d;
            dut.u_tmp1.tmp117_s0_data_raw_o=e; dut.u_tmp2.tmp117_s0_data_raw_o=f;
            dut.u_ads1.data_valid_o=1; dut.u_ads2.data_valid_o=1;
            dut.u_tmp1.tmp117_s0_data_valid_o=1; dut.u_tmp2.tmp117_s0_data_valid_o=1;
            @(negedge clk);
            dut.u_ads1.data_valid_o=0; dut.u_ads2.data_valid_o=0;
            dut.u_tmp1.tmp117_s0_data_valid_o=0; dut.u_tmp2.tmp117_s0_data_valid_o=0;
        end
    endtask
    initial begin
        repeat(5) @(negedge clk);
        rst=1;
        if(dut.u_ads1.SYS_CLOCK_FREQ!=50_000_000 || dut.u_ads2.CONF0_MUX!=3 ||
           dut.u_tmp1.NUM_SENSORS!=1 || dut.u_tmp2.NUM_SENSORS!=1)
            $fatal(1,"Wrapper parameter mapping");
        #30000000;
        publish(405797,-209077,20*32,35*32,25*128,30*128);
        #12000000; // Changes arrive while the previous snapshot is on the wire.
        publish(0,0,45*32,50*32,40*128,-20*128);
        #28000000;
        @(negedge clk);
        dut.u_tmp1.tmp117_s0_cfg_error_o=1;
        dut.u_ads2.drdy_timeout_error_o=1;
        #20000000;
        @(negedge clk);
        dut.u_tmp1.tmp117_s0_cfg_error_o=0;
        dut.u_ads2.drdy_timeout_error_o=0;
        // Clearing an error alone must not revive a pre-error sample.
        #40000000;
        publish(0,0,45*32,50*32,40*128,-20*128);
    end
    task read_byte(output reg [7:0] data);
        integer k;
        begin
            @(negedge tx);
            #(1e9/115200.0/2);
            if(tx!==0) $fatal(1,"UART start bit");
            for(k=0;k<8;k=k+1) begin
                #(1e9/115200.0); data[k]=tx;
            end
            #(1e9/115200.0);
            if(tx!==1) $fatal(1,"UART stop bit");
        end
    endtask
    integer line_index;
    reg [7:0] data;
    string line, expected, suffix;
    initial begin
        suffix=string'(EXTERNAL_CJ ? {",SRC=TMP",8'h0D,8'h0A} : {",SRC=ADS",8'h0D,8'h0A});
        wait(rst);
        for(line_index=0;line_index<7;line_index=line_index+1) begin
            line="";
            do begin
                read_byte(data);
                line={line,data};
                if(line.len()>120) $fatal(1,"UART line overrun");
            end while(data!=10);
            case(line_index)
                0,5: begin
                    expected={"TC1=ERR,TC2=ERR,TMP1=ERR,TMP2=ERR,CJ1=ERR,CJ2=ERR",suffix};
                    if(line!=expected) $fatal(1,"Missing/stale data not rejected: %s",line);
                end
                1: begin
                    // Quantized LUT + integer division results, checked byte for byte.
                    // Independent physical-temperature tolerance is covered by tb_k_type.
                    expected={EXTERNAL_CJ ? "TC1=+0099.99,TC2=-0010.01" : "TC1=+0095.11,TC2=-0004.79",
                        ",TMP1=+0025.00,TMP2=+0030.00,CJ1=+0020.00,CJ2=+0035.00",suffix};
                    if(line!=expected) $fatal(1,"Numeric/snapshot mismatch: %s",line);
                end
                2,6: begin
                    expected={EXTERNAL_CJ ? "TC1=+0040.00,TC2=-0020.00" : "TC1=+0045.00,TC2=+0050.00",
                        ",TMP1=+0040.00,TMP2=-0020.00,CJ1=+0045.00,CJ2=+0050.00",suffix};
                    if(line!=expected) $fatal(1,"New sample/recovery mismatch: %s",line);
                end
                3,4: begin
                    expected={EXTERNAL_CJ ? "TC1=ERR" : "TC1=+0045.00",
                        ",TC2=ERR,TMP1=ERR,TMP2=-0020.00,CJ1=+0045.00,CJ2=ERR",suffix};
                    if(line!=expected) $fatal(1,"Error handling/recovery mismatch: %s",line);
                end
            endcase
            $display("SRC=%0d line %0d PASS: %s",EXTERNAL_CJ,line_index,line);
        end
        finished=1;
    end
endmodule

module tb_temperature_test;
    wire internal_done,external_done;
    uart_scenario #(.EXTERNAL_CJ(0)) internal_cj(internal_done);
    uart_scenario #(.EXTERNAL_CJ(1)) external_cj(external_done);
    initial begin
        wait(internal_done && external_done);
        $display("PASS: both CJ selections, 14 UART lines, signed values, snapshots, errors, stale data and recovery");
        $finish;
    end
    initial begin #160000000; $fatal(1,"UART test timeout"); end
endmodule
