param(
    [string]$VivadoBin = 'C:\AMDDesignTools\2025.2\Vivado\bin',
    [string]$BuildDir = (Join-Path ([System.IO.Path]::GetTempPath()) ('temperature_test_' + [guid]::NewGuid().ToString('N')))
)
$ErrorActionPreference = 'Stop'
$sourceRoot = Split-Path -Parent $PSScriptRoot
foreach ($name in @('xvlog.bat','xelab.bat','xsim.bat')) {
    if (-not (Test-Path -LiteralPath (Join-Path $VivadoBin $name))) {
        throw "Simulator not found: $name. Set -VivadoBin."
    }
}
New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'conversion_vectors.txt') -Destination $BuildDir
$rtlFiles = @(Get-ChildItem -LiteralPath (Join-Path $sourceRoot 'rtl') -Filter '*.v' | ForEach-Object { $_.FullName })
$simFiles = @('sensor_port_models.sv','tb_k_type.sv','tb_temperature_test.sv') | ForEach-Object { Join-Path $PSScriptRoot $_ }
Push-Location $BuildDir
try {
    & (Join-Path $VivadoBin 'xvlog.bat') -sv @rtlFiles @simFiles
    if ($LASTEXITCODE -ne 0) { throw 'RTL compilation failed' }
    foreach ($tb in @('tb_k_type','tb_temperature_test')) {
        $snapshot = $tb + '_run'
        & (Join-Path $VivadoBin 'xelab.bat') $tb -s $snapshot
        if ($LASTEXITCODE -ne 0) { throw "Elaboration failed: $tb" }
        $logFile = $tb + '.log'
        & (Join-Path $VivadoBin 'xsim.bat') $snapshot -runall -log $logFile
        if ($LASTEXITCODE -ne 0) { throw "Simulation failed: $tb" }
        $logText = Get-Content -LiteralPath $logFile -Raw
        # XSim may return exit code 0 even after a Verilog $fatal or kernel error.
        if ($logText -match '(?im)\bFatal:|FATAL_ERROR|^ERROR:') { throw "Failure in $logFile" }
        $marker = if ($tb -eq 'tb_k_type') { 'PASS: 1254 conversion vectors' } else { 'PASS: both CJ selections, 14 UART lines' }
        if (-not $logText.Contains($marker)) { throw "Missing completion marker: $tb" }
    }
    Write-Host "All tests passed. Build and logs: $BuildDir"
} finally {
    Pop-Location
}
