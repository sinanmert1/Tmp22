`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 2026-10-19, v1.0 - Four-sensor board test. SystemVerilog compilation required.
// Existing ADS1220/TMP117 controllers are instantiated, not replaced.
// clk_i must be 50 MHz with default parameters. Physical pins are board-specific.
// Two independent SPI buses, two independent open-drain I2C buses, one UART TX.
// UART: 115200 baud, 8N1, one report/second by default. All values in C.
// USE_EXTERNAL_CJ: 1 = TMP1->TC1 and TMP2->TC2; 0 = each ADS internal CJ.
// The existing ADS controller ALWAYS reads its internal CJ, in either selection.
// -----------------------------------------------------------------------------
module temperature_test_top #(
    parameter CLK_FREQ = 50_000_000,
    parameter UART_BAUDRATE = 115200,
    parameter REPORT_PERIOD_MS = 1000,
    parameter STALE_TIMEOUT_MS = 3000,
    parameter USE_EXTERNAL_CJ = 0,
    parameter I2C_BUS_CLK_FREQ = 100_000,
    parameter [6:0] TMP1_ADDR = 7'h48,
    parameter [6:0] TMP2_ADDR = 7'h48,
    parameter ADC_GAIN = 32,
    parameter ADC_USE_EXTERNAL_REF = 0,
    parameter ADC_EXTERNAL_VREF_UV = 2_500_000
)(
    input clk_i, input rst_al_i,
    input ads1_miso_i, input ads1_drdy_al_i,
    output ads1_cs_o, output ads1_sclk_o, output ads1_mosi_o,
    input ads2_miso_i, input ads2_drdy_al_i,
    output ads2_cs_o, output ads2_sclk_o, output ads2_mosi_o,
    inout tmp1_scl_io, inout tmp1_sda_io,
    inout tmp2_scl_io, inout tmp2_sda_io,
    output uart_tx_o
);
    localparam [2:0] GAIN_FIELD = $clog2(ADC_GAIN);
    localparam [1:0] VREF_FIELD = ADC_USE_EXTERNAL_REF ? 2'd1 : 2'd0;
    localparam VREF_UV = ADC_USE_EXTERNAL_REF ? ADC_EXTERNAL_VREF_UV : 2_048_000;
    wire signed [23:0] tc1_w, tc2_w;
    wire signed [15:0] cj1_w, cj2_w;
    wire [15:0] tmp1_w, tmp2_w;
    wire [1:0] ads_valid_w, ads_cfg_error_w, ads_timeout_w, tmp_valid_w;
    wire [1:0] tmp_id_error_w, tmp_cfg_error_w, tmp_range_error_w;

    //###############################################################################
    //                              SENSOR INSTANTIATIONS
    //###############################################################################
    ads1220_thrmcpl_controller #(
        .SYS_CLOCK_FREQ(CLK_FREQ), .CONF0_MUX(4'd3),
        .CONF0_GAIN(GAIN_FIELD), .CONF2_VREF(VREF_FIELD)
    ) u_ads1 (
        .clk_i(clk_i), .rst_al_i(rst_al_i),
        .drdy_al_i(ads1_drdy_al_i), .miso_i(ads1_miso_i),
        .cs_o(ads1_cs_o), .sclk_o(ads1_sclk_o), .mosi_o(ads1_mosi_o),
        .tc_data_o(tc1_w), .cj_data_o(cj1_w), .data_valid_o(ads_valid_w[0]),
        .cfg_error_o(ads_cfg_error_w[0]), .drdy_timeout_error_o(ads_timeout_w[0])
    );
    ads1220_thrmcpl_controller #(
        .SYS_CLOCK_FREQ(CLK_FREQ), .CONF0_MUX(4'd3),
        .CONF0_GAIN(GAIN_FIELD), .CONF2_VREF(VREF_FIELD)
    ) u_ads2 (
        .clk_i(clk_i), .rst_al_i(rst_al_i),
        .drdy_al_i(ads2_drdy_al_i), .miso_i(ads2_miso_i),
        .cs_o(ads2_cs_o), .sclk_o(ads2_sclk_o), .mosi_o(ads2_mosi_o),
        .tc_data_o(tc2_w), .cj_data_o(cj2_w), .data_valid_o(ads_valid_w[1]),
        .cfg_error_o(ads_cfg_error_w[1]), .drdy_timeout_error_o(ads_timeout_w[1])
    );
    tmp117_controller #(
        .SYS_CLK_FREQ(CLK_FREQ), .I2C_BUS_CLK_FREQ(I2C_BUS_CLK_FREQ),
        .NUM_SENSORS(1), .DEVICE_ADDR_0(TMP1_ADDR)
    ) u_tmp1 (
        .clk_i(clk_i), .rst_al_i(rst_al_i),
        .tmp117_scl_io(tmp1_scl_io), .tmp117_sda_io(tmp1_sda_io),
        .tmp117_s0_data_valid_o(tmp_valid_w[0]), .tmp117_s0_data_raw_o(tmp1_w),
        .tmp117_s0_id_error_o(tmp_id_error_w[0]),
        .tmp117_s0_cfg_error_o(tmp_cfg_error_w[0]),
        .tmp117_s0_range_error_o(tmp_range_error_w[0]),
        .tmp117_s1_data_valid_o(), .tmp117_s1_data_raw_o(),
        .tmp117_s1_id_error_o(), .tmp117_s1_cfg_error_o(), .tmp117_s1_range_error_o()
    );
    tmp117_controller #(
        .SYS_CLK_FREQ(CLK_FREQ), .I2C_BUS_CLK_FREQ(I2C_BUS_CLK_FREQ),
        .NUM_SENSORS(1), .DEVICE_ADDR_0(TMP2_ADDR)
    ) u_tmp2 (
        .clk_i(clk_i), .rst_al_i(rst_al_i),
        .tmp117_scl_io(tmp2_scl_io), .tmp117_sda_io(tmp2_sda_io),
        .tmp117_s0_data_valid_o(tmp_valid_w[1]), .tmp117_s0_data_raw_o(tmp2_w),
        .tmp117_s0_id_error_o(tmp_id_error_w[1]),
        .tmp117_s0_cfg_error_o(tmp_cfg_error_w[1]),
        .tmp117_s0_range_error_o(tmp_range_error_w[1]),
        .tmp117_s1_data_valid_o(), .tmp117_s1_data_raw_o(),
        .tmp117_s1_id_error_o(), .tmp117_s1_cfg_error_o(), .tmp117_s1_range_error_o()
    );

    temp_test_reporter #(
        .CLK_FREQ(CLK_FREQ), .BAUDRATE(UART_BAUDRATE),
        .REPORT_PERIOD_MS(REPORT_PERIOD_MS), .STALE_TIMEOUT_MS(STALE_TIMEOUT_MS),
        .USE_EXTERNAL_CJ(USE_EXTERNAL_CJ), .ADC_GAIN(ADC_GAIN), .ADC_VREF_UV(VREF_UV)
    ) u_reporter (
        .clk_i(clk_i), .rst_al_i(rst_al_i),
        .tc1_i(tc1_w), .tc2_i(tc2_w), .cj1_i(cj1_w), .cj2_i(cj2_w),
        .ads_valid_i(ads_valid_w), .ads_error_i(ads_cfg_error_w | ads_timeout_w),
        .tmp1_i(tmp1_w), .tmp2_i(tmp2_w), .tmp_valid_i(tmp_valid_w),
        .tmp_error_i(tmp_id_error_w | tmp_cfg_error_w | tmp_range_error_w),
        .uart_tx_o(uart_tx_o)
    );
endmodule
