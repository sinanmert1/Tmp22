`timescale 1ns/1ps
// Captures independent latest samples. A report is a frozen snapshot, not a
// claim of simultaneous ADC sampling. Errors/stale data print ERR, never 0 C.
// With external CJ selected, a bad TMP invalidates its TC result as well.
module temp_test_reporter #(
    parameter CLK_FREQ=50_000_000, BAUDRATE=115200,
    parameter REPORT_PERIOD_MS=1000, STALE_TIMEOUT_MS=3000,
    parameter USE_EXTERNAL_CJ=0, ADC_GAIN=32, ADC_VREF_UV=2_048_000
)(
    input clk_i, input rst_al_i,
    input signed [23:0] tc1_i, tc2_i,
    input signed [15:0] cj1_i, cj2_i,
    input [1:0] ads_valid_i, ads_error_i,
    input [15:0] tmp1_i, tmp2_i,
    input [1:0] tmp_valid_i, tmp_error_i,
    output uart_tx_o
);
    localparam REPORT_CC=(CLK_FREQ/1000)*REPORT_PERIOD_MS;
    localparam STALE_CC=(CLK_FREQ/1000)*STALE_TIMEOUT_MS;
    localparam S_IDLE=0, S_CONV_START=1, S_CONV_WAIT=2, S_FIELD=3,
               S_BCD=4, S_EMIT=5, S_ACCEPT=6, S_TX_WAIT=7;
    reg [3:0] state;
    reg [31:0] report_timer_r;
    reg [31:0] age_r [0:3];
    reg [3:0] seen_r;
    reg signed [23:0] latest_tc_r [0:1], snapshot_tc_r [0:1];
    reg signed [15:0] latest_cj_r [0:1], latest_tmp_r [0:1];
    reg signed [31:0] snapshot_cj_q7_r [0:1];
    reg signed [31:0] value_r [0:5];
    reg [5:0] valid_r;
    wire [3:0] healthy_w;
    assign healthy_w[0]=seen_r[0] && age_r[0]<STALE_CC && !ads_error_i[0];
    assign healthy_w[1]=seen_r[1] && age_r[1]<STALE_CC && !ads_error_i[1];
    assign healthy_w[2]=seen_r[2] && age_r[2]<STALE_CC && !tmp_error_i[0];
    assign healthy_w[3]=seen_r[3] && age_r[3]<STALE_CC && !tmp_error_i[1];
    integer i;
    always @(posedge clk_i or negedge rst_al_i) begin
        if (!rst_al_i) begin
            seen_r<=0;
            for (i=0;i<4;i=i+1) age_r[i]<=STALE_CC;
            for (i=0;i<2;i=i+1) begin
                latest_tc_r[i]<=0; latest_cj_r[i]<=0; latest_tmp_r[i]<=0;
            end
        end else begin
            for (i=0;i<4;i=i+1) if (age_r[i]<STALE_CC) age_r[i]<=age_r[i]+1'b1;
            for (i=0;i<2;i=i+1) begin
                if (ads_error_i[i]) seen_r[i]<=0;
                else if (ads_valid_i[i]) begin
                    seen_r[i]<=1; age_r[i]<=0;
                    latest_tc_r[i]<=i==0 ? tc1_i : tc2_i;
                    latest_cj_r[i]<=i==0 ? cj1_i : cj2_i;
                end
                if (tmp_error_i[i]) seen_r[i+2]<=0;
                else if (tmp_valid_i[i]) begin
                    seen_r[i+2]<=1; age_r[i+2]<=0;
                    latest_tmp_r[i]<=i==0 ? tmp1_i : tmp2_i;
                end
            end
        end
    end
    reg conv_channel_r, conv_start_r;
    wire conv_busy_w, conv_done_w, conv_range_w;
    wire signed [31:0] conv_value_w;
    temp_test_k_type #(.ADC_GAIN(ADC_GAIN), .ADC_VREF_UV(ADC_VREF_UV)) u_convert (
        .clk_i(clk_i), .rst_al_i(rst_al_i), .start_i(conv_start_r),
        .tc_code_i(snapshot_tc_r[conv_channel_r]),
        .cj_q7_i(snapshot_cj_q7_r[conv_channel_r]),
        .busy_o(conv_busy_w), .done_o(conv_done_w),
        .range_error_o(conv_range_w), .temp_centi_o(conv_value_w)
    );
    reg uart_send_r;
    reg [7:0] uart_data_r;
    wire uart_busy_w;
    temp_test_uart_tx #(.CLK_FREQ(CLK_FREQ), .BAUDRATE(BAUDRATE)) u_uart (
        .clk_i(clk_i), .rst_al_i(rst_al_i), .send_i(uart_send_r),
        .data_i(uart_data_r), .tx_o(uart_tx_o), .busy_o(uart_busy_w)
    );
    reg [2:0] field_r;
    reg [1:0] part_r; // label, value, comma, footer
    reg [3:0] char_r;
    reg negative_r;
    reg [19:0] binary_r;
    reg [23:0] bcd_r, bcd_adjust_w;
    reg [4:0] bcd_count_r;
    integer d;
    always @(*) begin
        bcd_adjust_w=bcd_r;
        for (d=0;d<6;d=d+1)
            if (bcd_r[d*4 +: 4]>=5) bcd_adjust_w[d*4 +: 4]=bcd_r[d*4 +: 4]+4'd3;
    end
    function signed [31:0] raw_to_centi;
        input signed [15:0] raw;
        input internal_cj;
        reg signed [31:0] scaled;
        integer rounding, shift;
        begin
            scaled=raw*100; shift=internal_cj ? 5 : 7; rounding=internal_cj ? 16 : 64;
            if (scaled<0) raw_to_centi=-(((-scaled)+rounding) >>> shift);
            else raw_to_centi=(scaled+rounding) >>> shift;
        end
    endfunction
    function [3:0] label_length;
        input [2:0] field;
        begin label_length=(field==2 || field==3) ? 5 : 4; end
    endfunction
    function [7:0] label_char;
        input [2:0] field; input [3:0] pos;
        reg [39:0] text;
        begin
            case (field)
                0:text="TC1="; 1:text="TC2="; 2:text="TMP1=";
                3:text="TMP2="; 4:text="CJ1="; default:text="CJ2=";
            endcase
            label_char=text >> ((label_length(field)-1-pos)*8);
        end
    endfunction
    function [7:0] footer_char;
        input [3:0] pos;
        reg [79:0] text;
        begin
            text=USE_EXTERNAL_CJ ? {",SRC=TMP",8'h0D,8'h0A} : {",SRC=ADS",8'h0D,8'h0A};
            footer_char=text >> ((9-pos)*8);
        end
    endfunction
    reg [7:0] next_char_w;
    always @(*) begin
        next_char_w=8'h3F;
        case (part_r)
            0: next_char_w=label_char(field_r,char_r);
            1: begin
                if (!valid_r[field_r]) next_char_w=(char_r==0) ? "E" : "R";
                else case (char_r)
                    0:next_char_w=negative_r ? "-" : "+";
                    1:next_char_w=8'h30+{4'b0,bcd_r[23:20]};
                    2:next_char_w=8'h30+{4'b0,bcd_r[19:16]};
                    3:next_char_w=8'h30+{4'b0,bcd_r[15:12]};
                    4:next_char_w=8'h30+{4'b0,bcd_r[11:8]};
                    5:next_char_w=".";
                    6:next_char_w=8'h30+{4'b0,bcd_r[7:4]};
                    7:next_char_w=8'h30+{4'b0,bcd_r[3:0]};
                    default:next_char_w="?";
                endcase
            end
            2: next_char_w=",";
            3: next_char_w=footer_char(char_r);
        endcase
    end
    integer j;
    always @(posedge clk_i or negedge rst_al_i) begin
        if (!rst_al_i) begin
            state<=S_IDLE; report_timer_r<=0; conv_start_r<=0; conv_channel_r<=0;
            uart_send_r<=0; uart_data_r<=0; valid_r<=0;
            field_r<=0; part_r<=0; char_r<=0; negative_r<=0;
            binary_r<=0; bcd_r<=0; bcd_count_r<=0;
            for(j=0;j<6;j=j+1) value_r[j]<=0;
            for(j=0;j<2;j=j+1) begin snapshot_tc_r[j]<=0; snapshot_cj_q7_r[j]<=0; end
        end else begin
            uart_send_r<=0; conv_start_r<=0;
            if(report_timer_r==REPORT_CC-1) report_timer_r<=0;
            else report_timer_r<=report_timer_r+1'b1;
            case(state)
                S_IDLE: if(report_timer_r==REPORT_CC-1) begin
                    for(j=0;j<2;j=j+1) begin
                        snapshot_tc_r[j]<=latest_tc_r[j];
                        if(USE_EXTERNAL_CJ) snapshot_cj_q7_r[j]<=$signed(latest_tmp_r[j]);
                        else snapshot_cj_q7_r[j]<=$signed({{16{latest_cj_r[j][15]}},latest_cj_r[j]}) <<< 2;
                        value_r[j+2]<=raw_to_centi(latest_tmp_r[j],1'b0);
                        value_r[j+4]<=raw_to_centi(latest_cj_r[j],1'b1);
                        valid_r[j]<=healthy_w[j] && (!USE_EXTERNAL_CJ || healthy_w[j+2]);
                        valid_r[j+2]<=healthy_w[j+2]; valid_r[j+4]<=healthy_w[j];
                    end
                    conv_channel_r<=0; state<=S_CONV_START;
                end
                S_CONV_START: begin
                    if(valid_r[conv_channel_r]) begin conv_start_r<=1; state<=S_CONV_WAIT; end
                    else if(!conv_channel_r) conv_channel_r<=1;
                    else begin field_r<=0; state<=S_FIELD; end
                end
                S_CONV_WAIT: if(conv_done_w) begin
                    value_r[conv_channel_r]<=conv_value_w;
                    valid_r[conv_channel_r]<=!conv_range_w;
                    if(!conv_channel_r) begin conv_channel_r<=1; state<=S_CONV_START; end
                    else begin field_r<=0; state<=S_FIELD; end
                end
                S_FIELD: begin
                    negative_r<=value_r[field_r]<0;
                    binary_r<=value_r[field_r]<0 ? -value_r[field_r] : value_r[field_r];
                    bcd_r<=0; bcd_count_r<=0; part_r<=0; char_r<=0; state<=S_BCD;
                end
                S_BCD: begin
                    bcd_r<={bcd_adjust_w[22:0],binary_r[19]};
                    binary_r<={binary_r[18:0],1'b0};
                    if(bcd_count_r==19) state<=S_EMIT;
                    else bcd_count_r<=bcd_count_r+1'b1;
                end
                S_EMIT: if(!uart_busy_w) begin
                    uart_data_r<=next_char_w; uart_send_r<=1; state<=S_ACCEPT;
                end
                S_ACCEPT: if(uart_busy_w) state<=S_TX_WAIT;
                S_TX_WAIT: if(!uart_busy_w) begin
                    state<=S_EMIT;
                    case(part_r)
                        0: if(char_r==label_length(field_r)-1) begin part_r<=1; char_r<=0; end
                           else char_r<=char_r+1'b1;
                        1: if(char_r==(valid_r[field_r] ? 7 : 2)) begin
                               char_r<=0; part_r<=field_r==5 ? 3 : 2;
                           end else char_r<=char_r+1'b1;
                        2: begin field_r<=field_r+1'b1; state<=S_FIELD; end
                        3: if(char_r==9) state<=S_IDLE; else char_r<=char_r+1'b1;
                    endcase
                end
                default: state<=S_IDLE;
            endcase
        end
    end
endmodule
