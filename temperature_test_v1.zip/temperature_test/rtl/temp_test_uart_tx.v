`timescale 1ns/1ps
// 8N1 UART transmitter. One clock domain, active-low asynchronous reset.
// Send is accepted only when busy_o is low. No vendor primitives.
module temp_test_uart_tx #(
    parameter CLK_FREQ = 50_000_000,
    parameter BAUDRATE = 115200
)(
    input clk_i, input rst_al_i,
    input send_i, input [7:0] data_i,
    output tx_o, output busy_o
);
    localparam BIT_CC = (CLK_FREQ + BAUDRATE/2) / BAUDRATE;
    reg [31:0] timer_r;
    reg [3:0] bit_r;
    reg [9:0] frame_r;
    reg busy_r;
    always @(posedge clk_i or negedge rst_al_i) begin
        if (!rst_al_i) begin
            timer_r <= 0; bit_r <= 0; frame_r <= 10'h3FF; busy_r <= 0;
        end else if (!busy_r) begin
            if (send_i) begin
                frame_r <= {1'b1, data_i, 1'b0};
                timer_r <= 0; bit_r <= 0; busy_r <= 1;
            end
        end else if (timer_r == BIT_CC-1) begin
            timer_r <= 0;
            frame_r <= {1'b1, frame_r[9:1]};
            if (bit_r == 9) busy_r <= 0;
            else bit_r <= bit_r + 1'b1;
        end else timer_r <= timer_r + 1'b1;
    end
    assign tx_o = busy_r ? frame_r[0] : 1'b1;
    assign busy_o = busy_r;
endmodule
