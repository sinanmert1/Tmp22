`timescale 1ns/1ps
// K-type cold-junction compensation, using a 5 C piecewise-linear EMF table.
// tc_code_i: offset-corrected signed ADS1220 code, not degrees Celsius.
// cj_q7_i: signed C * 128. TMP117 raw is already Q7; ADS CJ raw needs x4.
// Output: signed C * 100, valid only with done_o && !range_error_o.
// Supported hot/CJ mathematical range: -200 .. +1372 C.
// A single iterative divider is reused; no combinational variable division.
module temp_test_k_type #(
    parameter ADC_GAIN = 32,
    parameter ADC_VREF_UV = 2_048_000
)(
    input clk_i, input rst_al_i, input start_i,
    input signed [23:0] tc_code_i,
    input signed [31:0] cj_q7_i,
    output reg busy_o, output reg done_o,
    output reg range_error_o,
    output reg signed [31:0] temp_centi_o
);
    localparam ADC_SHIFT = 23 + $clog2(ADC_GAIN);
    localparam signed [63:0] VREF_NV = 64'sd1000 * ADC_VREF_UV;
    localparam S_IDLE=0, S_CJ_FIND=1, S_CJ_PREP=2, S_DIV=3,
               S_ADD=4, S_CHECK=5, S_TC_FIND=6, S_TC_PREP=7,
               S_RESULT=8, S_DONE=9;
    reg [3:0] state;
    reg [8:0] low_r, high_r;
    wire [8:0] mid_w = ({1'b0,low_r} + {1'b0,high_r}) >> 1;
    reg signed [31:0] cj_r, emf_base_r, total_nv_r, base_centi_r;
    reg signed [63:0] adc_product_r;
    reg [31:0] quotient_r, denominator_r;
    reg [32:0] remainder_r;
    reg [5:0] div_count_r;
    reg inverse_r;
    wire [32:0] trial_w = {remainder_r[31:0], quotient_r[31]};
    wire signed [31:0] emf_low_w, emf_high_w, emf_mid_w;
    wire signed [31:0] low_q7_w = node_q7(low_r);
    wire signed [31:0] high_q7_w = node_q7(high_r);
    wire signed [31:0] mid_q7_w = node_q7(mid_w);
    temp_test_k_rom u_rom_low (.addr_i(low_r), .emf_nv_o(emf_low_w));
    temp_test_k_rom u_rom_high(.addr_i(high_r), .emf_nv_o(emf_high_w));
    temp_test_k_rom u_rom_mid (.addr_i(mid_w), .emf_nv_o(emf_mid_w));
    function signed [31:0] node_q7;
        input [8:0] index;
        begin
            if (index == 315) node_q7 = 1372 * 128;
            else node_q7 = ($signed({1'b0,index}) * 5 - 200) * 128;
        end
    endfunction
    always @(posedge clk_i or negedge rst_al_i) begin
        if (!rst_al_i) begin
            state<=S_IDLE; busy_o<=0; done_o<=0; range_error_o<=0;
            temp_centi_o<=0; low_r<=0; high_r<=315; cj_r<=0;
            emf_base_r<=0; total_nv_r<=0; base_centi_r<=0; adc_product_r<=0;
            quotient_r<=0; denominator_r<=1; remainder_r<=0;
            div_count_r<=0; inverse_r<=0;
        end else begin
            done_o <= 0;
            case (state)
                S_IDLE: if (start_i) begin
                    busy_o<=1; range_error_o<=0; temp_centi_o<=0;
                    cj_r<=cj_q7_i; adc_product_r <= tc_code_i * VREF_NV;
                    low_r<=0; high_r<=315;
                    if (cj_q7_i < -25600 || cj_q7_i > 175616 ||
                        tc_code_i == 24'sh7FFFFF || tc_code_i == 24'sh800000) begin
                        range_error_o<=1; state<=S_DONE;
                    end else state<=S_CJ_FIND;
                end
                S_CJ_FIND: begin
                    if (high_r-low_r <= 1) state<=S_CJ_PREP;
                    else if (cj_r >= mid_q7_w) low_r<=mid_w;
                    else high_r<=mid_w;
                end
                S_CJ_PREP: begin
                    emf_base_r <= emf_low_w;
                    quotient_r <= (emf_high_w-emf_low_w) * (cj_r-low_q7_w);
                    denominator_r <= high_q7_w-low_q7_w;
                    remainder_r<=0; div_count_r<=0; inverse_r<=0; state<=S_DIV;
                end
                S_DIV: begin
                    if (trial_w >= {1'b0,denominator_r}) begin
                        remainder_r <= trial_w - {1'b0,denominator_r};
                        quotient_r <= {quotient_r[30:0],1'b1};
                    end else begin
                        remainder_r <= trial_w;
                        quotient_r <= {quotient_r[30:0],1'b0};
                    end
                    if (div_count_r==31) state<=inverse_r ? S_RESULT : S_ADD;
                    else div_count_r<=div_count_r+1'b1;
                end
                S_ADD: begin
                    total_nv_r <= (adc_product_r >>> ADC_SHIFT) + emf_base_r + $signed(quotient_r);
                    low_r<=0; high_r<=315; state<=S_CHECK;
                end
                S_CHECK: begin
                    if (total_nv_r < emf_low_w || total_nv_r > emf_high_w) begin
                        range_error_o<=1; state<=S_DONE;
                    end else state<=S_TC_FIND;
                end
                S_TC_FIND: begin
                    if (high_r-low_r <= 1) state<=S_TC_PREP;
                    else if (total_nv_r >= emf_mid_w) low_r<=mid_w;
                    else high_r<=mid_w;
                end
                S_TC_PREP: begin
                    base_centi_r <= ($signed({1'b0,low_r}) * 5 - 200) * 100;
                    quotient_r <= (total_nv_r-emf_low_w) * ((high_r==315) ? 200 : 500);
                    denominator_r <= emf_high_w-emf_low_w;
                    remainder_r<=0; div_count_r<=0; inverse_r<=1; state<=S_DIV;
                end
                S_RESULT: begin
                    temp_centi_o <= base_centi_r + $signed(quotient_r);
                    state<=S_DONE;
                end
                S_DONE: begin busy_o<=0; done_o<=1; state<=S_IDLE; end
                default: begin range_error_o<=1; state<=S_DONE; end
            endcase
        end
    end
endmodule
