# Test sonuçları — 19 Ekim 2026

Araç: Vivado XSim 2025.2. Paketteki `sim/run_xsim.ps1` temiz bir çalışma
klasöründe çalıştırıldı ve iki test de tamamlandı.

| Kontrol | Sonuç |
|---|---|
| Yeni RTL ve top bağlantılarının derlenmesi | Geçti |
| 1.254 termokupl dönüşüm vektörü | Geçti |
| Dahili 2.048 V / harici 2.5 V ölçeği, kazanç 32 | Geçti |
| Negatif/pozitif CJ ve sıcaklıklar, sınırlar, kapsam dışı girişler | Geçti |
| Test örneklerinde referansa göre en büyük dönüşüm farkı | 0,05 °C |
| Dahili ve harici CJ seçimleriyle 14 UART satırı | Geçti |
| UART TX pininden 115200 8N1 çözümleme, satırların byte bazında karşılaştırılması | Geçti |
| Satır gönderilirken değişen sensör verisinin sonraki rapora aktarılması | Geçti |
| İlk veri bekleme, geçersiz/eski veri, hata ve yeni veriyle toparlanma | Geçti |
| Gönderilen SPI ve UART RX kopyalarının SHA-256 karşılaştırması | Kaynaklarla aynı |

Sayısal ek kontrol: 316 düğümlü LUT'nin 0,01 °C adımlarla taranan ters dönüşüm
ara değer hatası en çok 0,036283 °C oldu. NIST ileri eğrisi ile bağımsız yayımlanan
yaklaşık ters polinom arasındaki fark en çok 0,053527 °C oldu. Bunlar hesaplama
kontrolleridir; gerçek kart doğruluğu veya sensör doğruluğu değildir.

Simülasyonun tamamlanma mesajları:

```text
PASS: 1254 conversion vectors, both VREF settings, maximum error 5 centi-C
PASS: both CJ selections, 14 UART lines, signed values, snapshots, errors, stale data and recovery
```

**Kapsam sınırı:** Sensör controller'larının tam kaynakları yerine yalnızca
simülasyon port modelleri kullanıldı. Gerçek ADS1220/TMP117 SPI/I2C iletişimi,
Libero sentezi ve zamanlama analizi, fiziksel pinler ve kart üstü ölçümler bu
testlerin kapsamında değildir. Mevcut controller'ların projeye eklenmesi gerekir.
