# Dört sensörlü FPGA sıcaklık testi

Sürüm 1.0 — 19 Ekim 2026

`temperature_test_top`, mevcut `ads1220_thrmcpl_controller` modülünü iki kez ve
`tmp117_controller` modülünü iki kez örnekler. İki SPI ve iki I2C hattı bağımsızdır.
Mevcut sensör modüllerinin içeriği değiştirilmedi. TMP117 örneklerinin her biri
`NUM_SENSORS=1` ile kendi hattındaki tek sensörü okur.

## Projeye ekleme

1. `rtl/` içindeki beş `.v` dosyasını Libero projesine ekle.
2. Kendi `ads1220_pkg`, `ads1220_thrmcpl_controller`, `tmp117_controller`,
   `spi_master` ve TMP117'nin kullandığı alt modüller projede bulunmalı.
   Package, ADS controller'dan önce derlenmeli.
3. Top olarak `temperature_test_top` seç. Mevcut package/packed array kullanımı
   nedeniyle ilgili dosyaları **SystemVerilog** olarak derle; `.v` uzantısı tek
   başına dil seçimini garanti etmez.
4. Eval board bağlantına göre fiziksel pinleri ve I/O standartlarını ata.
   `clk_i` girişine 50 MHz uygula; saat kısıtı 20 ns olmalı.
   `rst_al_i` aktif düşük reset; sistem entegrasyonunda resetin bırakılmasını
   50 MHz saate senkronla.
5. UART terminalini **115200 baud, 8 veri biti, parite yok, 1 stop biti,
   flow control yok** olarak aç. Varsayılan rapor periyodu bir saniyedir.

**`sim/sensor_port_models.sv` dosyasını FPGA projesine ekleme.** Bu dosya sadece
simülasyonda veri üretir; SPI veya I2C üzerinden sensör okumaz.

Pakette ADS1220 ve TMP117 controller'larının tam kaynakları yoktur. Bağlantıları
gönderilen port görsellerine göre yapıldı. `reference/` içindeki SPI ve UART RX
dosyaları, gönderdiğin dosyaların değiştirilmemiş kopyalarıdır. UART RX bu testte
kullanılmaz; raporlama için ayrı `temp_test_uart_tx` eklendi.

## UART satırı

Örnek biçim; bütün sayısal alanların birimi °C:

```text
TC1=+0125.30,TC2=+0087.65,TMP1=+0025.12,TMP2=+0025.34,CJ1=+0026.00,CJ2=+0026.25,SRC=ADS
```

| Alan | İçerik |
|---|---|
| TC1, TC2 | CJ telafisi yapılmış K tipi termokupl sıcaklıkları |
| TMP1, TMP2 | Harici TMP117 sıcaklıkları |
| CJ1, CJ2 | İki ADS1220'nin dahili sıcaklık ölçümleri |
| SRC | TC hesabında kullanılan CJ kaynağı: ADS veya TMP |

İstenen dört sıcaklık ilk dört alandır. Son iki sıcaklık, dahili CJ ile TMP117
karşılaştırmasını yapabilmek için eklenmiştir. Satır CR+LF ile biter.
Sayılar işaretli, dört tam ve iki ondalık basamaklıdır; iki ondalık basamak
ölçüm doğruluğu iddiası değildir.

Her rapor başında son geçerli değerlerin kopyası alınır. Gönderim sırasında gelen
yeni ölçümler bir sonraki rapora geçer. Sensörler aynı anda örneklenmiş sayılmaz.
Sensör hatası, henüz veri gelmemesi, son geçerli verinin üç saniyeyi aşması veya
termokupl dönüşümünün kapsam dışı olması durumunda ilgili alan `ERR` olur.
Hata kalktıktan sonra yeni geçerli ölçüm beklenir.

## Başlıca parametreler

| Parametre | Varsayılan | Açıklama |
|---|---:|---|
| CLK_FREQ | 50_000_000 | Sistem saati, Hz |
| UART_BAUDRATE | 115200 | UART hızı |
| REPORT_PERIOD_MS | 1000 | Rapor periyodu, ms |
| STALE_TIMEOUT_MS | 3000 | Geçerli ölçüm bekleme sınırı, ms |
| USE_EXTERNAL_CJ | 0 | 0: ADS dahili CJ; 1: TMP117 |
| I2C_BUS_CLK_FREQ | 100_000 | Her bağımsız I2C hattının hızı |
| TMP1_ADDR / TMP2_ADDR | 7'h48 / 7'h48 | Her hat için bağımsız 7 bit adres |
| ADC_GAIN | 32 | ADS PGA kazancı ve hesaplama ölçeği birlikte ayarlanır |
| ADC_USE_EXTERNAL_REF | 0 | 0: dahili 2.048 V; 1: REFP0/REFN0 |
| ADC_EXTERNAL_VREF_UV | 2_500_000 | Harici referans seçildiğinde kullanılan µV değeri |

TMP2 şemasında ADD0 GND'ye bağlıdır. TMP1'in adres bağlantısı paylaşılan sayfalarda
görülmediğinden varsayılanı 0x48 bırakıldı. Hatlar bağımsız olduğundan iki sensörün
aynı adreste olması sorun oluşturmaz. TMP1 ADD0 farklı bağlıysa sadece TMP1_ADDR
değiştirilmelidir.

Varsayılan `USE_EXTERNAL_CJ=0` mevcut ADS dahili CJ akışını kullanır. Değeri 1
yapıldığında TMP1, TC1 için; TMP2, TC2 için CJ kaynağı olur. Bu seçim derleme
parametresidir; UART komutu değildir. ADS dahili CJ okumaları her iki seçimde de
devam eder. TMP kaynaklı kullanımda ilgili TMP hatası o TC sonucunu da geçersiz
kılar; otomatik olarak diğer kaynağa geçilmez.

Şemadaki REF3425'i kullanmak istersen `ADC_USE_EXTERNAL_REF=1` seç. Böylece hem
ADS register seçimi hem ADC kodunun gerilime dönüşüm ölçeği 2.5 V olur. Varsayılan
dahili 2.048 V seçimidir. AIN bağlantısı AIN1 (+), AIN2 (-) olarak ayarlıdır.
Bu paket kazanç 32 ile doğrulandı; diğer desteklenen kazançlar 1,2,4,8,16,64,128'dir.

## Hesaplama

```text
V_TC = signed(tc_data) × VREF / (GAIN × 2^23)
T_TMP = signed(tmp_raw) / 128
T_CJ_ADS = signed(cj_data) / 32
V_toplam = V_TC + E_K(T_CJ)
T_TC = E_K^-1(V_toplam)
```

ADS controller'ın `tc_data_o` çıkışının offset düzeltmesi uygulanmış ham ADC kodu,
`cj_data_o` çıkışının 14 bit dahili sıcaklık kodunun 16 bite işaret genişletilmiş
hali olduğu esas alındı. Paylaşılan çıkış atamaları bu biçimi gösteriyor.
TMP117'nin 16 bit çıkışı top içinde işaretli olarak değerlendirilir.

K tipi dönüşüm için -200…+1372 °C aralığında, 5 °C adımlı 316 düğümlü tablo ve
doğrusal ara değer hesabı kullanılır; son aralık 1370…1372 °C'dir. CJ'nin °C
değeri doğrudan termokupl sıcaklığına eklenmez, önce eşdeğer gerilime çevrilir.
Donanımda kayan nokta veya işlemci yoktur; iki TC hesabı aynı dönüşüm bloğunu
sırayla kullanır. Tablo RTL içindedir; `.mem` dosyası yüklemek gerekmez.

Bu matematiksel aralık, CJ sensörlerinin fiziksel ölçüm aralığı değildir.
TMP117 veya ADS die sıcaklığının gerçek terminal sıcaklığını temsil etmesi
yerleşime ve ısıl temasa bağlıdır. İki okumayı karşılaştırmak tek başına hangi
sensörün daha doğru olduğunu belirlemez.

## Mevcut ADS kodunda kontrol edilecek satır

Gönderilen controller görselinde `STATE_WIDTH = 9`, son durum ise
`S_CFG_CJ_DIS = 'd512` görünüyor. 512 için 10 bit gerekir; 9 bitte bu sabit sıfıra
kesilir ve belirtilen one-hot kodlamayla uyuşmaz. Kendi kaynak dosyanda da aynıysa
`STATE_WIDTH = 10` olarak düzelt. Mevcut kaynak dosya burada bulunmadığı için bu
değişiklik paketten otomatik uygulanmadı. Bu bulgu yeni top simülasyonunda
denetlenmiş bir controller düzeltmesi olarak değerlendirilmemeli.

## Donanım bağlantısı

Top portları iki ayrı beş telli SPI grubu, iki ayrı SCL/SDA çifti, UART TX,
saat ve resettir. Kart modeline ve bağlanacak konnektöre özel pin numaraları
verilmediği için PDC/pin ataması uydurulmadı. I2C controller'ın open-drain
sürücüsü mevcut modülde kalır.

Paylaşılan şemada 5 V ile beslenen SPI tamponları var. FPGA tarafına ulaşan MISO
ve DRDY seviyesini bağlantıdan önce kontrol et; IGLOO2 girişlerine doğrudan 5 V
uygulama. I/O bankasına uygun seviye dönüşümü ve ortak GND gerekir.

## Doğrulama kapsamı

`sim/` klasöründe dönüşüm testi, iki CJ seçimini kapsayan UART testi, test
vektörleri ve tablo üreticisi bulunur. Testler Vivado XSim ile çalıştırılır;
bu araç seçimi FPGA hedefini değiştirmez. RTL'de Xilinx primitive kullanılmaz.

Testlerde gerçek sensör controller'ları yerine **port modelleri** kullanılır.
Dolayısıyla bu doğrulama yeni top bağlantılarını, dönüşümü ve UART raporlamasını
kapsar; mevcut SPI/I2C akışlarını, Libero sentezini, IGLOO2 kaynak kullanımını,
50 MHz zamanlama kapanışını veya gerçek kart ölçümünü doğrulamaz.

Yeniden çalıştırma (PowerShell, Vivado kurulum yolunu gerektiğinde değiştir):

```powershell
./sim/run_xsim.ps1 -VivadoBin 'C:\AMDDesignTools\2025.2\Vivado\bin'
```

## Referanslar

- [TI ADS1220 veri sayfası](https://www.ti.com/lit/ds/symlink/ads1220.pdf): ADC ve dahili sıcaklık kod biçimleri.
- [TI TMP117 veri sayfası](https://www.ti.com/lit/ds/symlink/tmp117.pdf): işaretli sıcaklık ölçeği ve adresler.
- [NIST ITS-90 / SRD 60](https://its90.nist.gov/): K tipi referans eğrisi.
- [Analog Devices, Table 3](https://www.analog.com/en/resources/design-notes/guidelines-to-implementing-temperature-measurements-with-the-max22000.html): bağımsız ters polinom kontrolü.
- [TI termokupl ölçüm rehberi](https://www.ti.com/lit/an/sbaa274/sbaa274.pdf): CJ telafisi ve yerleşim.
- [Microchip UG0445, bölüm 6.13](https://ww1.microchip.com/downloads/aemDocuments/documents/FPGA/ProductDocuments/SoC/microsemi_smartfusion2_igloo2_fabric_user_guide_ug0445_v8.pdf): giriş gerilimi sınırları.
